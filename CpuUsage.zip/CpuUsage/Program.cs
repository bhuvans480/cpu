﻿using System;
using System.Diagnostics;

namespace CpuUsage
{
    public class Program
    {
        public PerformanceCounter cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
        protected PerformanceCounter ramCounter = new PerformanceCounter("Memory", "Available MBytes");
        public static void Main()
        {
            for(int i=0; i<1000; i++)
            {
                Program obj = new Program();
                Console.WriteLine("CPU Usage: " + obj.getCurrentCpuUsage());
                Console.WriteLine("CPU Usage: " + obj.getAvailableRAM());
            }
        }
        public string getCurrentCpuUsage()
        {
            return cpuCounter.NextValue() + "%";
        }

        public string getAvailableRAM()
        {
            return ramCounter.NextValue() + "MB";
        }
    }
}



